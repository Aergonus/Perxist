			<script type="text/javascript" src="./js/Libraries/three.min.js"></script>
			<script type="text/javascript" src="./js/Libraries/stats.min.js"></script>
			<script type="text/javascript" src="./js/Libraries/Detector.js"></script>
			<script type="text/javascript" src="./js/Libraries/MouseControls.js"></script>
			<script type="text/javascript" src="./js/Libraries/FlyControls.js"></script>
			<script type="text/javascript" src="./js/Libraries/FirstPersonControls.js"></script>
			<script type="text/javascript" src="./js/Libraries/PointerLockControls.js"></script>